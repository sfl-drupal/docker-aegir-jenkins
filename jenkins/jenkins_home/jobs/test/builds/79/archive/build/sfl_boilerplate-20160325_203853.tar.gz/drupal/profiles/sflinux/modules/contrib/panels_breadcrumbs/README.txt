
Panels Breadcrumbs module
-----------------
by Diogo Correia, diogocorreia@devuo.net

Panels Breadcrumbs allows you to set your breadcrumbs directly from Panels
variant configuration, and also allows you to take advantage from Panels 
Arguments and Contexts as Placeholder tokens.
